var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ventas/estadisticas/route.js")
R.c("server/chunks/18f8d_next_6b0d0476._.js")
R.c("server/chunks/18f8d_@supabase_storage-js_dist_module_a638b735._.js")
R.c("server/chunks/18f8d_@supabase_auth-js_dist_module_f984e64e._.js")
R.c("server/chunks/18f8d_0a83b232._.js")
R.c("server/chunks/[root-of-the-server]__f29d2f34._.js")
R.c("server/chunks/d8912__next-internal_server_app_api_ventas_estadisticas_route_actions_c05b02f3.js")
R.m("[project]/robles-payment-app/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/robles-payment-app/src/app/api/ventas/estadisticas/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/robles-payment-app/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/robles-payment-app/src/app/api/ventas/estadisticas/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
