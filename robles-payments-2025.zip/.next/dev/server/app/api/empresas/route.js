var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/empresas/route.js")
R.c("server/chunks/18f8d_next_beca8d4a._.js")
R.c("server/chunks/[root-of-the-server]__6053f012._.js")
R.c("server/chunks/robles-payment-app__next-internal_server_app_api_empresas_route_actions_e9a1e845.js")
R.m("[project]/robles-payment-app/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/robles-payment-app/src/app/api/empresas/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/robles-payment-app/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/robles-payment-app/src/app/api/empresas/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
