var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/empresas/activas/route.js")
R.c("server/chunks/18f8d_next_7c84561e._.js")
R.c("server/chunks/[root-of-the-server]__cbc290d6._.js")
R.c("server/chunks/d8912__next-internal_server_app_api_empresas_activas_route_actions_680a8df8.js")
R.m("[project]/robles-payment-app/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/robles-payment-app/src/app/api/empresas/activas/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/robles-payment-app/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/robles-payment-app/src/app/api/empresas/activas/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
