var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/config/status/route.js")
R.c("server/chunks/18f8d_next_f5bf5567._.js")
R.c("server/chunks/[root-of-the-server]__8b429185._.js")
R.c("server/chunks/d8912__next-internal_server_app_api_config_status_route_actions_c3d1aae2.js")
R.m("[project]/robles-payment-app/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/robles-payment-app/src/app/api/config/status/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/robles-payment-app/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/robles-payment-app/src/app/api/config/status/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
