module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/types/index.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "limpiarNombreEmpresa",
    ()=>limpiarNombreEmpresa
]);
const limpiarNombreEmpresa = (nombreCompleto)=>{
    // Formatos soportados: "1 - Empresa A", "1 Empresa A", "Empresa A (1)"
    const patterns = [
        /^(\d+)\s*-\s*(.+)$/,
        /^(\d+)\s+(.+)$/,
        /^(.+)\s*\((\d+)\)$/
    ];
    for (const pattern of patterns){
        const match = nombreCompleto.match(pattern);
        if (match) {
            if (pattern === patterns[2]) {
                // Formato "Empresa A (1)"
                return {
                    id: parseInt(match[2]),
                    nombre: match[1].trim()
                };
            } else {
                // Formatos "1 - Empresa A" o "1 Empresa A"
                return {
                    id: parseInt(match[1]),
                    nombre: match[2].trim()
                };
            }
        }
    }
    // Si no coincide con ningún patrón, asumir que es solo nombre
    return {
        id: 1,
        nombre: nombreCompleto.trim()
    };
};
}),
"[project]/src/lib/googleSheets.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GoogleSheetsService",
    ()=>GoogleSheetsService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$index$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/types/index.ts [app-route] (ecmascript)");
;
const SPREADSHEET_ID = '1ThgfHPMCgOAaobuhsyhFboRitIEWFvCDnw-oRR_VlD0';
// URLs para acceso CSV público de Google Sheets
const EMPRESAS_CSV_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/export?format=csv&gid=0`;
const VENTAS_CSV_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/export?format=csv&gid=1`;
class GoogleSheetsService {
    static parseCSV(csvText) {
        const lines = csvText.split('\n');
        return lines.map((line)=>{
            const result = [];
            let current = '';
            let inQuotes = false;
            for(let i = 0; i < line.length; i++){
                const char = line[i];
                if (char === '"') {
                    inQuotes = !inQuotes;
                } else if (char === ',' && !inQuotes) {
                    result.push(current.trim());
                    current = '';
                } else {
                    current += char;
                }
            }
            result.push(current.trim());
            return result;
        }).filter((row)=>row.some((cell)=>cell.length > 0));
    }
    static async getEmpresas() {
        try {
            const response = await fetch(EMPRESAS_CSV_URL);
            const csvText = await response.text();
            const rows = this.parseCSV(csvText);
            // Asume que la primera fila son los headers
            const dataRows = rows.slice(1);
            return dataRows.map((row)=>{
                const nombreCompleto = row[0] || '';
                const { id, nombre } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$index$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["limpiarNombreEmpresa"])(nombreCompleto);
                return {
                    id,
                    nombre,
                    nombreCompleto
                };
            }).filter((empresa)=>empresa.nombre.length > 0);
        } catch (error) {
            console.error('Error fetching empresas:', error);
            // Fallback con datos de ejemplo
            return [
                {
                    id: 1,
                    nombre: 'Empresa A',
                    nombreCompleto: '1 - Empresa A'
                },
                {
                    id: 2,
                    nombre: 'Empresa B',
                    nombreCompleto: '2 - Empresa B'
                },
                {
                    id: 3,
                    nombre: 'Empresa C',
                    nombreCompleto: '3 - Empresa C'
                }
            ];
        }
    }
    static async getPagos() {
        try {
            const response = await fetch(VENTAS_CSV_URL);
            const csvText = await response.text();
            const rows = this.parseCSV(csvText);
            // Asume que la primera fila son los headers
            const dataRows = rows.slice(1);
            return dataRows.map((row, index)=>({
                    id: index + 1,
                    empresaId: parseInt(row[0] || '0'),
                    nombreCliente: row[1] || '',
                    apellidoCliente: row[2] || '',
                    importe: parseFloat(row[3] || '0'),
                    metodoPago: row[4] || '',
                    fechaPago: row[5] || '',
                    empresaNombre: row[6] || ''
                })).filter((pago)=>pago.nombreCliente.length > 0);
        } catch (error) {
            console.error('Error fetching pagos:', error);
            return [];
        }
    }
    static async addPago(pago) {
        try {
            // Para agregar datos, necesitaríamos usar Google Apps Script o Google Sheets API
            // Por ahora, simularemos el éxito
            console.log('Pago a agregar:', pago);
            // En una implementación real, usarías Google Apps Script o Google Sheets API
            // con autenticación adecuada para escribir datos
            return true;
        } catch (error) {
            console.error('Error adding pago:', error);
            return false;
        }
    }
}
}),
"[project]/src/app/api/empresas/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$googleSheets$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/googleSheets.ts [app-route] (ecmascript)");
;
;
async function GET() {
    try {
        const empresas = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$googleSheets$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GoogleSheetsService"].getEmpresas();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(empresas);
    } catch (error) {
        console.error('Error in GET /api/empresas:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Error fetching empresas'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__64325d36._.js.map