module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/robles-payment-app/src/lib/supabase.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/robles-payment-app/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
;
const supabaseUrl = ("TURBOPACK compile-time value", "https://oymqyoynzovvlxwbtaci.supabase.co");
const supabaseAnonKey = ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im95bXF5b3luem92dmx4d2J0YWNpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIzOTkyMjAsImV4cCI6MjA3Nzk3NTIyMH0.X5IGoMTYVWAGR51yzQ2hudOy2fTGMfkOOPw6ICO7rZ0");
console.log('🔧 Supabase Config:', {
    url: ("TURBOPACK compile-time truthy", 1) ? 'Configurado ✅' : "TURBOPACK unreachable",
    key: ("TURBOPACK compile-time truthy", 1) ? 'Configurado ✅' : "TURBOPACK unreachable"
});
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseAnonKey);
}),
"[project]/robles-payment-app/src/lib/supabaseService.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SupabaseService",
    ()=>SupabaseService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/robles-payment-app/src/lib/supabase.ts [app-route] (ecmascript)");
;
class SupabaseService {
    // Obtener todas las ventas
    static async getVentas() {
        try {
            console.log('🔍 Supabase: Fetching ventas from table "Ventas"...');
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabase"].from('Ventas').select('*').order('created_at', {
                ascending: false
            });
            if (error) {
                console.error('❌ Supabase Error fetching ventas:', {
                    error: error,
                    message: error.message,
                    details: error.details,
                    hint: error.hint,
                    code: error.code
                });
                return [];
            }
            console.log('✅ Supabase: Ventas fetched successfully:', data?.length || 0, 'records');
            return data || [];
        } catch (error) {
            console.error('🚨 Critical error in getVentas:', error);
            return [];
        }
    }
    // Agregar una nueva venta
    static async addVenta(venta) {
        try {
            console.log('💾 Supabase: Starting to add venta...', venta);
            console.log('🔗 Supabase URL:', ("TURBOPACK compile-time value", "https://oymqyoynzovvlxwbtaci.supabase.co"));
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabase"].from('Ventas').insert([
                venta
            ]).select().single();
            if (error) {
                console.error('❌ Supabase Error inserting venta:', {
                    error: error,
                    message: error.message,
                    details: error.details,
                    hint: error.hint,
                    code: error.code,
                    stack: error.stack
                });
                console.error('💡 Check if table "Ventas" exists and has proper structure');
                return null;
            }
            console.log('✅ Venta agregada exitosamente a Supabase:', data);
            return data;
        } catch (error) {
            console.error('🚨 Critical error in addVenta:', error);
            return null;
        }
    }
    // Obtener ventas por empresa
    static async getVentasPorEmpresa(nombreEmpresa) {
        try {
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabase"].from('Ventas').select('*').eq('nombre_empresa', nombreEmpresa).order('created_at', {
                ascending: false
            });
            if (error) {
                console.error('Error fetching ventas por empresa from Supabase:', error);
                return [];
            }
            return data || [];
        } catch (error) {
            console.error('Error in getVentasPorEmpresa:', error);
            return [];
        }
    }
    // Obtener estadísticas de ventas
    static async getEstadisticasVentas() {
        try {
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabase"].from('Ventas').select('nombre_empresa, importe');
            if (error) {
                console.error('Error fetching estadísticas from Supabase:', error);
                return {
                    totalVentas: 0,
                    totalTransacciones: 0,
                    ventasPorEmpresa: []
                };
            }
            const ventasPorEmpresa = data?.reduce((acc, venta)=>{
                const empresa = venta.nombre_empresa;
                if (!acc[empresa]) {
                    acc[empresa] = {
                        totalVentas: 0,
                        cantidadVentas: 0
                    };
                }
                acc[empresa].totalVentas += Number(venta.importe);
                acc[empresa].cantidadVentas += 1;
                return acc;
            }, {});
            const totalVentas = data?.reduce((sum, venta)=>sum + Number(venta.importe), 0) || 0;
            const totalTransacciones = data?.length || 0;
            return {
                totalVentas,
                totalTransacciones,
                ventasPorEmpresa: Object.entries(ventasPorEmpresa || {}).map(([empresa, stats])=>({
                        empresa,
                        totalVentas: stats.totalVentas,
                        cantidadVentas: stats.cantidadVentas
                    }))
            };
        } catch (error) {
            console.error('Error in getEstadisticasVentas:', error);
            return {
                totalVentas: 0,
                totalTransacciones: 0,
                ventasPorEmpresa: []
            };
        }
    }
}
}),
"[project]/robles-payment-app/src/app/api/pagos/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/robles-payment-app/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$src$2f$lib$2f$supabaseService$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/robles-payment-app/src/lib/supabaseService.ts [app-route] (ecmascript)");
;
;
async function GET() {
    try {
        const ventas = await __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$src$2f$lib$2f$supabaseService$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SupabaseService"].getVentas();
        return __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(ventas);
    } catch (error) {
        console.error('Error in GET /api/pagos:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Error fetching ventas from Supabase'
        }, {
            status: 500
        });
    }
}
async function POST(request) {
    try {
        const body = await request.json();
        console.log('📥 API: Recibido pago para agregar a Supabase:', body);
        // Validar datos requeridos
        if (!body.empresaNombre || !body.nombreCliente || !body.importe) {
            console.error('❌ API: Datos faltantes en el cuerpo de la petición');
            return __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Datos faltantes: empresaNombre, nombreCliente, importe son requeridos'
            }, {
                status: 400
            });
        }
        // Transformar el formato de pago al formato de Supabase
        const ventaData = {
            nombre_empresa: body.empresaNombre,
            nombre_cliente: body.nombreCliente,
            importe: parseFloat(body.importe)
        };
        console.log('🔄 API: Transformando datos para Supabase:', ventaData);
        const nuevaVenta = await __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$src$2f$lib$2f$supabaseService$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SupabaseService"].addVenta(ventaData);
        if (nuevaVenta) {
            console.log('✅ API: Venta registrada exitosamente:', nuevaVenta);
            return __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                message: 'Venta registrada exitosamente en Supabase',
                data: nuevaVenta
            });
        } else {
            console.error('❌ API: SupabaseService.addVenta retornó null');
            return __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Error al registrar venta en Supabase - revisar logs de Supabase'
            }, {
                status: 500
            });
        }
    } catch (error) {
        console.error('🚨 API: Error crítico in POST /api/pagos:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$robles$2d$payment$2d$app$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Error creating venta: ' + error
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__86805ecc._.js.map