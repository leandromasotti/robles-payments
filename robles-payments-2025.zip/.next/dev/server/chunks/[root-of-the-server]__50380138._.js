module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/googleSheets.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GoogleSheetsService",
    ()=>GoogleSheetsService
]);
const SPREADSHEET_ID = '1ThgfHPMCgOAaobuhsyhFboRitIEWFvCDnw-oRR_VlD0';
// URLs para acceso CSV público de Google Sheets
const EMPRESAS_CSV_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/export?format=csv&gid=0`;
const VENTAS_CSV_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/export?format=csv&gid=1`;
class GoogleSheetsService {
    static parseCSV(csvText) {
        const lines = csvText.split('\n');
        return lines.map((line)=>{
            const result = [];
            let current = '';
            let inQuotes = false;
            for(let i = 0; i < line.length; i++){
                const char = line[i];
                if (char === '"') {
                    inQuotes = !inQuotes;
                } else if (char === ',' && !inQuotes) {
                    result.push(current.trim());
                    current = '';
                } else {
                    current += char;
                }
            }
            result.push(current.trim());
            return result;
        }).filter((row)=>row.some((cell)=>cell.length > 0));
    }
    static async getEmpresas() {
        try {
            const response = await fetch(EMPRESAS_CSV_URL);
            const csvText = await response.text();
            console.log('CSV de empresas recibido:', csvText); // Debug
            const rows = this.parseCSV(csvText);
            // Asume que la primera fila son los headers
            const dataRows = rows.slice(1);
            return dataRows.map((row)=>{
                const id = parseInt(row[0] || '0');
                const nombre = (row[1] || '').toUpperCase().trim();
                const vigencia = (row[2] || '').toUpperCase().trim(); // Segunda columna para vigencia
                console.log('Procesando empresa:', {
                    id,
                    nombre,
                    vigencia
                });
                return {
                    id,
                    nombre,
                    vigencia,
                    activa: vigencia === 'X' // Solo activa si tiene 'X'
                };
            }).filter((empresa)=>empresa.nombre.length > 0);
        } catch (error) {
            console.error('Error fetching empresas:', error);
            // Fallback con datos de ejemplo
            return [
                {
                    id: 1,
                    nombre: 'Empresa A',
                    nombreCompleto: '1 - Empresa A',
                    vigencia: 'X',
                    activa: true
                },
                {
                    id: 2,
                    nombre: 'Empresa B',
                    nombreCompleto: '2 - Empresa B',
                    vigencia: 'X',
                    activa: true
                },
                {
                    id: 3,
                    nombre: 'Empresa C',
                    nombreCompleto: '3 - Empresa C',
                    vigencia: '',
                    activa: false
                }
            ];
        }
    }
    // Método específico para obtener solo empresas activas (con vigencia X)
    static async getEmpresasActivas() {
        const todasLasEmpresas = await this.getEmpresas();
        return todasLasEmpresas.filter((empresa)=>empresa.activa);
    }
    static async getPagos() {
        try {
            const response = await fetch(VENTAS_CSV_URL);
            const csvText = await response.text();
            const rows = this.parseCSV(csvText);
            // Asume que la primera fila son los headers
            const dataRows = rows.slice(1);
            return dataRows.map((row, index)=>({
                    id: index + 1,
                    empresaId: parseInt(row[0] || '0'),
                    nombreCliente: row[1] || '',
                    apellidoCliente: row[2] || '',
                    importe: parseFloat(row[3] || '0'),
                    metodoPago: row[4] || '',
                    fechaPago: row[5] || '',
                    empresaNombre: row[6] || ''
                })).filter((pago)=>pago.nombreCliente.length > 0);
        } catch (error) {
            console.error('Error fetching pagos:', error);
            return [];
        }
    }
    static async addPago(pago) {
        // Este método ya no se usa directamente desde las APIs
        // La lógica se movió a /api/pagos para evitar problemas de fetch server-to-server
        console.log('Pago para agregar (método deprecado):', pago);
        return true;
    }
}
}),
"[project]/src/app/api/empresas/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$googleSheets$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/googleSheets.ts [app-route] (ecmascript)");
;
;
async function GET() {
    try {
        const empresas = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$googleSheets$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GoogleSheetsService"].getEmpresas();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(empresas);
    } catch (error) {
        console.error('Error in GET /api/empresas:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Error fetching empresas'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__50380138._.js.map