module.exports = [
"[project]/robles-payment-app/.next-internal/server/app/api/pagos/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=robles-payment-app__next-internal_server_app_api_pagos_route_actions_c15a052d.js.map