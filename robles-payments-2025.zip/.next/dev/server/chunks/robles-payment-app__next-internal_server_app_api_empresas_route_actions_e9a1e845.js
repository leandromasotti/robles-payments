module.exports = [
"[project]/robles-payment-app/.next-internal/server/app/api/empresas/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=robles-payment-app__next-internal_server_app_api_empresas_route_actions_e9a1e845.js.map