module.exports = [
"[project]/.next-internal/server/app/api/pagos/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_pagos_route_actions_291d4d2a.js.map