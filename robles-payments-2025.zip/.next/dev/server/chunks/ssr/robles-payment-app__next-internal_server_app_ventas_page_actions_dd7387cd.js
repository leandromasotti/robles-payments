module.exports = [
"[project]/robles-payment-app/.next-internal/server/app/ventas/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=robles-payment-app__next-internal_server_app_ventas_page_actions_dd7387cd.js.map