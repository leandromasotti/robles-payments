module.exports = [
"[project]/robles-payment-app/.next-internal/server/app/empresas/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=robles-payment-app__next-internal_server_app_empresas_page_actions_4dee7bb8.js.map