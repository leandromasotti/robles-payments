module.exports = [
"[project]/robles-payment-app/.next-internal/server/app/pago-exitoso/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=robles-payment-app__next-internal_server_app_pago-exitoso_page_actions_402db466.js.map