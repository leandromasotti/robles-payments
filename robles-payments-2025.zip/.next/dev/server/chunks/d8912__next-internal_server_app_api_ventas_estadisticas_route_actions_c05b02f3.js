module.exports = [
"[project]/robles-payment-app/.next-internal/server/app/api/ventas/estadisticas/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=d8912__next-internal_server_app_api_ventas_estadisticas_route_actions_c05b02f3.js.map