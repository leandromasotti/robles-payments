module.exports = [
"[project]/.next-internal/server/app/api/empresas/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_empresas_route_actions_10ff8e60.js.map