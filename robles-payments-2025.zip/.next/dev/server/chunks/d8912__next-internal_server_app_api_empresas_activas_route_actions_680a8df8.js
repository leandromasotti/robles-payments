module.exports = [
"[project]/robles-payment-app/.next-internal/server/app/api/empresas/activas/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=d8912__next-internal_server_app_api_empresas_activas_route_actions_680a8df8.js.map