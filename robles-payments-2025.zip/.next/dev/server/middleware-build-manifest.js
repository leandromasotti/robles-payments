globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/18f8d_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_5969e351._.js",
    "static/chunks/18f8d_next_dist_compiled_react-dom_b2ad03af._.js",
    "static/chunks/18f8d_next_dist_compiled_react-server-dom-turbopack_a72d3343._.js",
    "static/chunks/18f8d_next_dist_compiled_next-devtools_index_bcbf872a.js",
    "static/chunks/18f8d_next_dist_compiled_d56688f2._.js",
    "static/chunks/18f8d_next_dist_client_e0690213._.js",
    "static/chunks/18f8d_next_dist_5d13683f._.js",
    "static/chunks/18f8d_@swc_helpers_cjs_0de8c809._.js",
    "static/chunks/robles-payment-app_a0ff3932._.js",
    "static/chunks/turbopack-robles-payment-app_16c18bcd._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];