(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_5969e351._.js",
  "static/chunks/18f8d_next_dist_compiled_react-dom_b2ad03af._.js",
  "static/chunks/18f8d_next_dist_compiled_react-server-dom-turbopack_a72d3343._.js",
  "static/chunks/18f8d_next_dist_compiled_next-devtools_index_bcbf872a.js",
  "static/chunks/18f8d_next_dist_compiled_d56688f2._.js",
  "static/chunks/18f8d_next_dist_client_e0690213._.js",
  "static/chunks/18f8d_next_dist_5d13683f._.js",
  "static/chunks/18f8d_@swc_helpers_cjs_0de8c809._.js"
],
    source: "entry"
});
