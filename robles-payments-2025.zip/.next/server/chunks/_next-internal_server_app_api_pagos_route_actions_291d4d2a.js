module.exports=[64421,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pagos_route_actions_291d4d2a.js.map