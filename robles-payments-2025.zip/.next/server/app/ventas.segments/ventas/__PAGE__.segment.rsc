1:"$Sreact.fragment"
2:I[88589,["/_next/static/chunks/c50a1fb090a560c4.js"],"default"]
3:I[33202,["/_next/static/chunks/c50a1fb090a560c4.js"],"default"]
4:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"OutletBoundary"]
5:"$Sreact.suspense"
0:{"buildId":"NVsX-E3u9QDolWhcRNnrV","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-screen bg-gray-50","children":[["$","$L2",null,{}],["$","main",null,{"className":"py-12","children":["$","$L3",null,{}]}],["$","footer",null,{"className":"bg-white border-t py-8 mt-12","children":["$","div",null,{"className":"max-w-7xl mx-auto px-4 text-center","children":[["$","h5",null,{"className":"text-lg font-semibold text-gray-800 mb-2","children":"BANCO ROBLES"}],["$","p",null,{"className":"text-gray-600","children":"2025 - TODOS LOS DERECHOS RESERVADOS"}]]}]}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/c50a1fb090a560c4.js","async":true}]],["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"loading":null,"isPartial":false}
6:null
