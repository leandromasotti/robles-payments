var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/pagos/route.js")
R.c("server/chunks/[root-of-the-server]__9aaaa81f._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_pagos_route_actions_291d4d2a.js")
R.m(13387)
module.exports=R.m(13387).exports
