var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/empresas/route.js")
R.c("server/chunks/[root-of-the-server]__99f86a99._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_empresas_route_actions_10ff8e60.js")
R.m(48841)
module.exports=R.m(48841).exports
